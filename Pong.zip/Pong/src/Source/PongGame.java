/*package Source;
public class PongGame {
    public static void main(String[] args) {
        new StartupWindow();
        //new instance of StartupWindow is created
        //StartupWindow class's constructor is called when new StartupWindow() is executed
    }
}*/