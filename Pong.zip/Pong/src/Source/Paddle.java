
package Source;//imports all classes from the custom Source package
import java.awt.*; //imports all classes in AWT package for GUI components
import java.awt.event.*; //imports AWT's event-handling classes
public class Paddle extends Rectangle implements keys{//subclass of Rectangle superclass
    int id;//either 1 or 2: 1 for player 1 and 2 for player 2
    int yVelocity;//how fast paddle moves up and down when we press a button
    int speed=10;//decides the speed of movement of paddles ie how much the paddle moves with each key press

    Paddle(int x,int y, int PADDLE_WIDTH,int PADDLE_HEIGHT,int id){//constructor for Paddle
        //can call super constructor of Rectangle class to assign some of these values
        super(x,y,PADDLE_WIDTH,PADDLE_HEIGHT);
        this.id=id;//assign the received id
    }
    @Override
    //handles key press events for moving the paddle.
    public void keyPressed(KeyEvent e){
        switch (id){//switch that examines the contents of id variable
            case 1://FOR PADDLE 1
                if (e.getKeyCode()==KeyEvent.VK_W){//if W is entered on keyboard this code block gets executed
                    setYDirection(-speed);//moves up on the Y axis
                    move();
                }
                if (e.getKeyCode()==KeyEvent.VK_S){//if S is entered on keyboard this code block gets executed
                    setYDirection(speed);//moves down on the Y axis
                    move();
                }
                break;
            case 2://FOR PADDLE 2
                if (e.getKeyCode()==KeyEvent.VK_UP){//if UP arrow is entered on keyboard this code block gets executed
                    setYDirection(-speed);//moves up on the Y axis
                    move();
                }
                if (e.getKeyCode()==KeyEvent.VK_DOWN){//if DOWN arrow is entered on keyboard this code block gets executed
                    setYDirection(speed);//moves down on the Y axis
                    move();
                }
                break;
        }
    }
    @Override
    public void keyReleased(KeyEvent e){
        //speed=0 to make sure the paddle does NOT move forever
        //paddle stops moving when these keys are released
        switch (id){//switch that examines the contents of id variable
            case 1://FOR PADDLE 1
                if (e.getKeyCode()==KeyEvent.VK_W){//if W is entered on keyboard this code block gets executed
                    setYDirection(0);//moves up on the Y axis
                    move();
                }
                if (e.getKeyCode()==KeyEvent.VK_S){//if S is entered on keyboard this code block gets executed
                    setYDirection(0);//moves down on the Y axis
                    move();
                }
                break;
            case 2://FOR PADDLE 2
                if (e.getKeyCode()==KeyEvent.VK_UP){//if UP arrow is entered on keyboard this code block gets executed
                    setYDirection(0);//moves up on the Y axis
                    move();
                }
                if (e.getKeyCode()==KeyEvent.VK_DOWN){//if DOWN arrow is entered on keyboard this code block gets executed
                    setYDirection(0);//moves down on the Y axis
                    move();
                }
                break;
        }
    }

    //sets the y-direction of the paddle based on the key event
    public void setYDirection(int yDirection){

        yVelocity=yDirection;
    }
    //moves the paddle's position based on the y-direction speed
    public void move(){
        y=y+yVelocity;
    }

    //draws the paddle with the specified color and position on the window.
    public void draw(Graphics g){
        if (id==1){
            g.setColor(new Color(255, 195, 0));
        }
        else{
            g.setColor(new Color(0, 255, 249));
        }

        g.fillRect(x,y,width,height);
    }
}
