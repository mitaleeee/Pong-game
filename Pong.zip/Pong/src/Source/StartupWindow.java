package Source;//imports all classes from the custom Source package
import javax.swing.*;//all Swing components
import java.awt.*;//all AWT components
public class StartupWindow extends JFrame {
    private JButton startButton;
    private JLabel titleLabel;
    private JLabel difficultyLabel;
    private JTextField difficultyTextField;

    public StartupWindow() {//constructor for StartupWindow

        setTitle("Pong Game Setup");
        getContentPane().setBackground(Color.BLACK);
        setSize(1000, 555);
        setLayout(new GridBagLayout()); //use GridBagLayout for center alignment

        //GridBagConstraints is used to specify the properties of components
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        //initialize titleLabel and set its properties
        titleLabel = new JLabel("PING PONG GAME");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Consolas", Font.BOLD, 80));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.insets = new Insets(10, 0, 10, 0);//for padding
        add(titleLabel, gbc);

        //initialize difficultyLabel and set its properties
        difficultyLabel = new JLabel("Difficulty Level:");
        difficultyLabel.setForeground(Color.BLUE);
        difficultyLabel.setFont(new Font("Consolas", Font.PLAIN, 20));
        difficultyLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(difficultyLabel, gbc);

        //initialize difficultyTextField and set its properties
        difficultyTextField = new JTextField();
        difficultyTextField.setFont(new Font("Consolas", Font.PLAIN, 20));
        difficultyTextField.setHorizontalAlignment(JTextField.CENTER);
        add(difficultyTextField, gbc);

        //initialize startButton and set its properties
        startButton = new JButton("Start Game");
        startButton.setFont(new Font("Consolas", Font.BOLD, 20));
        startButton.setForeground(new Color(204, 204, 0));
        startButton.setBackground(Color.BLACK);
        startButton.setBorder(BorderFactory.createLineBorder(Color.BLACK));//color of border=black
        startButton.setFocusPainted(false); //don't paint the focus indicator
        startButton.setFocusable(false); //make the button not focusable
        startButton.setContentAreaFilled(false); //necessary for some L&F implementations
        startButton.setOpaque(true);

        //adds an action listener that calls startGame() when the button is pressed
        startButton.addActionListener(e -> startGame());
        add(startButton, gbc);

        //sets the location of the window relative to the screen center
        setLocationRelativeTo(null);
        //makes the window visible
        setVisible(true);
        //sets the default close operation
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void startGame() {
        try {
            //parses the difficulty level from the text field
            //convert the string provided as an argument into an integer
            int difficulty = Integer.parseInt(difficultyTextField.getText());
            //ensure speed is between 1 and 10
            int initialSpeed = Math.max(1, Math.min(difficulty, 10));
            //creates a new GameFrame with the initial speed
            GameFrame gameFrame = new GameFrame(initialSpeed);
        } catch (NumberFormatException e) {
            //shows an error message if the difficulty level is not a valid number
            JOptionPane.showMessageDialog(this, "Please enter a valid difficulty level (1-10).", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
        dispose(); //close the startup window
    }
}
