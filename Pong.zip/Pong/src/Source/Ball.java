package Source;//imports all classes from the custom Source package
import java.awt.*; //imports all classes in AWT package for GUI components
import java.util.*;//imports the utility classes, such as Random
public class Ball extends Rectangle{
    Random random;//instance of random class to generate random directions
    int xVelocity;//how fast the ball is going to move on the x axis
    int yVelocity;//how fast the ball is going to move on the y axis
    private int speed;

    //constructor for the Ball class
    Ball(int x, int y, int width, int height,int initialSpeed){
        //ball is subclass of Rectangle superclass so we can call super constructor to assign these arguments
        super(x,y,width,height);
        initialSpeed=initialSpeed+1;
        this.speed = initialSpeed; //assign the initial speed to the speed variable

        random=new Random();
        int randomXDirection= random.nextInt(2);//gives either 0 or 1
        //if 0, have the ball go left, if 1, ball goes right
        if(randomXDirection==0)
            randomXDirection--;//go left
        setXDirection(randomXDirection*initialSpeed);
        int randomYDirection= random.nextInt(2);//gives either 0 or 1
        //if 0, have the ball go left, if 1, ball goes right
        if(randomYDirection==0)
            randomYDirection--;//go left
        setYDirection(randomYDirection*initialSpeed);
    }

    public void setXDirection(int randomXDirection){
        //set the horizontal direction of the ball
        xVelocity=randomXDirection;
    }

    public void setYDirection(int randomYDirection){
        //set the vertical direction of the ball
        yVelocity=randomYDirection;
    }
    public void move(){
        //updates the ball's position based on its velocity
        x+=xVelocity;
        y+=yVelocity;
    }
    public void draw(Graphics g){
        //draws the ball on the screen
        g.setColor(Color.white);
        g.fillOval(x,y,width,height);
    }
}
