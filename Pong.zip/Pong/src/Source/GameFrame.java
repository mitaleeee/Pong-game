package Source;//imports all classes from the custom Source package
import java.awt.*; //imports all classes in AWT package for GUI components
import java.awt.event.*; //imports AWT's event-handling classes
import javax.swing.*; //imports all Swing framework classes
public class GameFrame extends JFrame{
    GamePanel panel;
    //constructor for GameFrame that takes an initial speed as its parameter
    public GameFrame(int initialSpeed){
        //initializes panel with given initial speed & adds it to frame
        panel=new GamePanel(initialSpeed);
        this.add(panel);//add GamePanel to GameFrame

        this.setTitle("Pong Game");//set title of frame
        this.setResizable(false);//we don't want the frame to be resizable
        this.setBackground(new Color(43, 13, 55));//whole frame background will be black
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE)      ;//frame closes upon clicking exit
        this.pack();//pack method of JFrame class
        //causes the window to be sized to fit the preferred size and layout of its subcomponents
        //we don't need to set the size of our JFrame, it's doing to adjust according to accomodate the size of GamePanel(the painting)

        this.setVisible(true);//to be able to see the frame
        this.setLocationRelativeTo(null);//the frame appears at the middle of your computer screen

        //adds a window listener for the window closing event
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0); //exit application when window is closed
            }
        });
    }
}
