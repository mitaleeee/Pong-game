package Source;//imports all classes from the custom Source package
import java.awt.*; //imports all classes in AWT package for GUI components
public class Score extends Rectangle{
    static int GAME_WIDTH;
    static int GAME_HEIGHT;
    int player1;//holds current score of player 1
    int player2;//holds current score of player 2

    Score(int GAME_WIDTH,int GAME_HEIGHT){
        //since the class' gamewidth and gameheight variables are static we need to set them using class name
        Score.GAME_WIDTH=GAME_WIDTH;
        Score.GAME_HEIGHT=GAME_HEIGHT;
    }

    public void draw(Graphics g){
        g.setColor(Color.white);
        //font type consolas, font plain not bold, font size 60
        g.setFont(new Font("Consolas", Font.PLAIN,50));
        //enter string to display, its x position and y position
        //string=1st digit= 10's place of player score and 2nd digit= 1's place of player score
        g.drawString(String.valueOf(player1/10)+String.valueOf(player1%10),((GAME_WIDTH/2)-85),50);
        g.drawString(String.valueOf(player2/10)+String.valueOf(player2%10),((GAME_WIDTH/2)+20),50);

        //for line in the middle of the game
        //enter starting x and y position (x1,y1) and then ending x and y position(x2,y2
        g.drawLine(GAME_WIDTH/2,0,GAME_WIDTH/2,GAME_HEIGHT);
    }
}
