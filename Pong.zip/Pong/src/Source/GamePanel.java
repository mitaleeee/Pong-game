package Source;//imports all classes from the custom Source package
import java.awt.*; //imports all classes in AWT package for GUI components
import java.awt.event.*; //imports AWT's event-handling classes
import javax.swing.*; //imports all Swing framework classes
import java.util.*;//imports the utility classes, such as Random

interface keys{
    //interface with two methods for handling key events
    void keyPressed(KeyEvent e);
    void keyReleased(KeyEvent e);
}
public class GamePanel extends JPanel implements Runnable{
    //to run it on a thread

    //set game dimensions
    static final int GAME_WIDTH=1000;
    static final int GAME_HEIGHT=(int)(GAME_WIDTH*(0.5555));//dimension of standard ping pong table-corresponding to GAME_WIDTH
    static final Dimension SCREEN_SIZE = new Dimension(GAME_WIDTH,GAME_HEIGHT);//create a dimension

    //set ball and paddle dimensions
    static final int BALL_DIAMETER=20;//20 pixels diameter
    static final int PADDLE_WIDTH=25;
    static final int PADDLE_HEIGHT=100;
    //STATIC- if we had multiple instances of GamePanel class, they'd all share just 1 variable and wouldn't each have their own individual GAME_WIDTH
    //FINAL- prohibits us from modifying our GAME_WIDTH later on in the program ALSO makes it run a little bit faster
    //================INSTANCES OF THE CLASSES
    Thread gameThread;//since we're implementing Runnable
    //declares a Thread variable for running the game loop
    Image image;
    //declares an Image object to be used for double buffering (to prevent flickering in animations)
    Graphics graphics;
    //declares a Graphics object for drawing images and shapes on the panel
    Random random;
    //declares a Random object to generate random numbers for ball movement

    Paddle paddle1;//for player 1
    Paddle paddle2;//for player 2
    Ball ball;
    Score score;

    private int ballSpeed;
    public GamePanel(int initialSpeed){//constructor
        //sets the ball speed to the passed initial speed value
        this.ballSpeed = initialSpeed;
        newPaddles(); //calls the method to create new paddles
        newBall(); //calls the method to create a new ball
        score=new Score(GAME_WIDTH,GAME_HEIGHT);//instantiating instance of Score class called score
        //passed game_width and game_height into the constructor

        this.setFocusable(true);//allows the panel to receive keyboard input
        this.addKeyListener(new AL());//we want to add an action listener so that it responds to key events
        this.setPreferredSize(SCREEN_SIZE);//sets the preferred size of the panel to the defined screen size
        //creates a new thread with this class (GamePanel) as its Runnable target
        //gameThread=gun, this=bullet <-required to start thread
        gameThread=new Thread(this);//since we're implementing Runnable interface
        gameThread.start();//to start the thread, it calls the run() method

    }
    public void newBall(){
        //to have the ball spawn in the middle of the window, x,y,diameter,diameter passed into the constructor
        //ball=new Ball(((GAME_WIDTH/2)-(BALL_DIAMETER/2)),((GAME_HEIGHT/2)-(BALL_DIAMETER/2)),BALL_DIAMETER,BALL_DIAMETER);
        random=new Random();//to have it spawn anywhere on the middle line y axis ie on range of GAME_HEIGHT-BALL_DIAMETER
        ball=new Ball(((GAME_WIDTH/2)-(BALL_DIAMETER/2)),random.nextInt(GAME_HEIGHT-BALL_DIAMETER),BALL_DIAMETER,BALL_DIAMETER,ballSpeed);
    }
    public void newPaddles(){
        paddle1=new Paddle(0,((GAME_HEIGHT/2)-(PADDLE_HEIGHT/2)),PADDLE_WIDTH,PADDLE_HEIGHT,1);//1=unique id number
        //left most- x=0-->on y axis it must be in the middle so gameheight/2 but also subtract paddleheight from it
        paddle2=new Paddle(GAME_WIDTH-PADDLE_WIDTH,((GAME_HEIGHT/2)-(PADDLE_HEIGHT/2)),PADDLE_WIDTH,PADDLE_HEIGHT,2);//2=unique id number
        //here x=right most position-paddle width


    }
    public void paint(Graphics g){
        image= createImage(getWidth(),getHeight());//create an image that has the dimensions of width and height of our game panel
        graphics= image.getGraphics();//create a graphic from image
        draw(graphics);//to draw all the components and pass the graphic that we created from our image
        g.drawImage(image,0,0,this);//draws the off-screen image onto the panel
        //pass (image, x coord y coord, this-our gamepanel)
        //           starts top left corner
    }
    public void draw(Graphics g){
        paddle1.draw(g);//draws paddle 1
        paddle2.draw(g);
        ball.draw(g);
        score.draw(g);
    }
    public void move(){//moves the paddles and ball smoothly
        //call each individual move methods after each iteration of our game loop
        //this method is called in each iteration so inside that we move each component individually
        paddle1.move();
        paddle2.move();
        ball.move();
    }
    public void checkCollision(){//set boundaries of window

        //bounce the ball off the top and bottom window edges
        if(ball.y<=0){//if you're moving UP and out of window
            ball.setYDirection(-ball.yVelocity);//ball will go in the opposite direction
        }
        if(ball.y>=(GAME_HEIGHT-BALL_DIAMETER)){//if you're moving DOWN and out of window
            ball.setYDirection(-ball.yVelocity);//ball will go in the opposite direction
        }

        //bounce the ball off the paddles
        //check if ball intersects w paddle1-using intersects() method of rectangle class
        if(ball.intersects(paddle1)){//checks for collision between these 2 objects
            ball.xVelocity=Math.abs(ball.xVelocity);//bounces off in opposite direction
            //-------optional----for more difficulty
            ball.xVelocity++;//to increase velocity after colliding with a paddle
            if(ball.yVelocity>0)
                ball.yVelocity++;
            //---------------------------------------
            else
                ball.yVelocity--;//if yvelocity is negative, it means its upwards and we're going to increase upwards velocity
            //set x and y directions w new values of velocities
            ball.setXDirection(ball.xVelocity);
            ball.setYDirection(ball.yVelocity);
        }
        if(ball.intersects(paddle2)){//checks for collision between these 2 objects
            ball.xVelocity=Math.abs(ball.xVelocity);//bounces off in opposite direction
            //-------optional----for more difficulty
            ball.xVelocity++;//to increase velocity after colliding with a paddle
            if(ball.yVelocity>0)
                ball.yVelocity++;
                //---------------------------------------
            else
                ball.yVelocity--;//if yvelocity is negative, it means its upwards and we're going to increase upwards velocity
            //set x and y directions w new values of velocities
            ball.setXDirection(-ball.xVelocity);//flip xvelocity
            ball.setYDirection(ball.yVelocity);
        }

        //stops paddles at window edges-stops it from going out
        if (paddle1.y<=0)//if you're moving UP and out of window
            paddle1.y=0;//set it to the topmost edge
        if (paddle1.y>=(GAME_HEIGHT-PADDLE_HEIGHT))//if you're moving DOWN and out of window
            paddle1.y=GAME_HEIGHT-PADDLE_HEIGHT;//set it to the bottommost edge
        if (paddle2.y<=0)//if you're moving UP and out of window
            paddle2.y=0;
        if (paddle2.y>=(GAME_HEIGHT-PADDLE_HEIGHT))//if you're moving DOWN and out of window
            paddle2.y=GAME_HEIGHT-PADDLE_HEIGHT;

        //give a player 1 point and creates new paddles and ball
        if(ball.x<=0){//touched the left boundary-->player 2 gets a point
            score.player2++;
            newPaddles();
            newBall();
            //System.out.println(score.player2);
        }
        if (ball.x>=GAME_WIDTH-BALL_DIAMETER){//touched right boundary so player 1 gets a point
            score.player1++;
            newPaddles();
            newBall();
        }
    }
    @Override //runnable interface
    public void run(){
        //game loop for a target of 60 frames per second FPS

        long lastTime = System.nanoTime(); //gets the current time in nanoseconds
        //to keep track of the time when the last update occurred
        double amountOfTicks = 60.0;
        //sets the desired number of updates per second
        double ns = 1000000000 / amountOfTicks; //calculates the number of nanoseconds per tick
        //(the time between each game update)
        double delta = 0;
        //used to keep track of how much time has passed since the last update
        while (true){
            long now = System.nanoTime(); //current time in nanoseconds
            delta += (now - lastTime) / ns; //adds the fraction of time passed since the last update
            lastTime = now; //updates the last time
            if (delta >= 1){
                //checks if enough time has passed to perform an update
                move(); //moves all components
                checkCollision(); //checks for collisions
                repaint(); //repaints everything
                delta--; //decreases delta by 1 time used for the update
            }
        }
    }
    public class AL extends KeyAdapter implements keys{//AL=ActionListener INNER CLASS
        @Override
        public void keyPressed(KeyEvent e){
            //method is invoked when a key has been pressed down
            paddle1.keyPressed(e);
            paddle2.keyPressed(e);
            //calls to the keyPressed methods of paddle1 and paddle2
        }
        @Override
        public void keyReleased(KeyEvent e){
            //method is invoked when a key has been released
            paddle1.keyReleased(e);
            paddle2.keyReleased(e);
        }
    }
}
