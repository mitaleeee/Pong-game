import Source.*;
import javax.swing.*; //imports all Swing framework classes
public class main {
    public static void main(String[] args) {
        //new instance of StartupWindow is created
        //StartupWindow class's constructor is called when new StartupWindow() is executed
        SwingUtilities.invokeLater(StartupWindow::new);
        //SwingUtilities.invokeLater -> tells Swing to run the code inside invokeLater on the EDT at a later time
        /*
        StartupWindow::new -> method reference in Java, shorthand for creating a Runnable that will call the StartupWindow constructor
        equivalent to -> new StartupWindow().
           creates an instance of the StartupWindow class
           ensures that this instance is created on the EDT Event Dispatch Thread
           does so at the next available opportunity, not immediately
              cuz thread safety(Swing components are not thread-safe)
              and event handling(EDT is dedicated to handling GUI event processing)
         */
    }
}
